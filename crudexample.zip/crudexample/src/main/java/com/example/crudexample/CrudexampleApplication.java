package com.example.crudexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudexampleApplication.class, args);
	}

}
